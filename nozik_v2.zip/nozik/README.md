# Nozik Bot v2 — O'rnatish va Deploy Qo'llanmasi

## 1. Eski repo bilan ishlash
1. GitHub'da eski `Nozik`/`UltimateForexSignalBot` repositoryga kiring.
2. Eski fayllarni o'chiring (yoki repo Settings > Delete repository orqali butunlay o'chirib, yangisini yarating).
3. Ushbu papkadagi barcha fayllarni yangi/tozalangan repo'ga yuklang (GitHub mobil ilovasida "Add file" > "Upload files" orqali qilsa bo'ladi).

## 2. Fayllar tuzilishi
```
nozik/
├── bot.py                  # Asosiy Telegram bot
├── config.py                # Sozlamalar (kalitlar Render'dan olinadi)
├── requirements.txt          # Python kutubxonalari
├── render.yaml               # Render.com deploy konfiguratsiyasi
├── signals/
│   ├── volume_oi.py          # Bybit volume + OI spike
│   ├── whale_tracker.py      # Whale Alert on-chain kuzatuv
│   ├── ict_smc.py            # BOS/CHoCH, Order Block, Liquidity Sweep
│   └── sentiment.py          # LunarCrush sentiment
└── engine/
    ├── aggregator.py         # 4 signalni birlashtiradi (confluence score)
    └── evaluator.py          # /pump_stats uchun signal aniqlik tarixi
```

## 3. Render.com'da sozlash
1. Render Dashboard > New > Web Service > GitHub repo'ni tanlang.
2. `render.yaml` avtomatik aniqlanadi (Blueprint sifatida).
3. Quyidagi Environment Variables'larni albatta to'ldiring:
   - `TELEGRAM_BOT_TOKEN` — BotFather'dan olingan token
   - `ADMIN_CHAT_IDS` — sizning Telegram chat ID'ingiz (vergul bilan bir nechtasi mumkin)
   - `BYBIT_API_KEY` / `BYBIT_API_SECRET` — Bybit hisobingizdan
   - `WHALE_ALERT_API_KEY` — https://whale-alert.io/ dan (whale tracking uchun majburiy)
   - `LUNARCRUSH_API_KEY` — https://lunarcrush.com/developers dan (sentiment uchun majburiy)
4. Deploy tugmasini bosing.

## 4. Eslatmalar
- **Whale Alert va LunarCrush API kalitlari bo'lmasa**, ular modul sifatida ishlashda davom etadi, lekin score = 0 qaytaradi (xatoga olib kelmaydi) — botning qolgan qismi normal ishlaydi.
- **Bybit API kalitlari** faqat public market data (kline, OI) uchun kerak bo'lsa, aslida kalitsiz ham public endpoint'lar ishlaydi — lekin xavfsizlik va rate-limit uchun kalit qo'shish tavsiya etiladi.
- `ALERT_THRESHOLD` (config.py'da, default 65) — bot avtomatik xabar yuborish uchun minimal confluence score. Signal juda ko'p/kam kelsa, shu qiymatni Render Environment Variables'dan o'zgartirsangiz bo'ladi (kodni qayta yozmasdan).
- `WATCHLIST` — kuzatiladigan coinlar, Environment Variable orqali osongina o'zgartiriladi.

## 5. Test qilish
Deploy'dan keyin Telegram botingizga quyidagilarni yozib ko'ring:
- `/start` — bot ishlayotganini tekshirish
- `/check BTCUSDT` — bitta coin uchun to'liq signal tahlili
- `/scan` — butun watchlist bo'yicha tezkor skanerlash
- `/pump_stats` — hozircha bo'sh bo'ladi, signal yig'ilgach statistika ko'rinadi
